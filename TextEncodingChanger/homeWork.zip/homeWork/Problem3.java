
public class Problem3{

	public static void main(String[] args){
	
		int cInt = 0x0667;
		System.out.println(Character.isDigit(cInt));
		
	
	
	}
}
